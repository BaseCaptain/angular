import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup , Validators ,FormBuilder  } from '@angular/forms';
import { Employee } from 'src/fromday62ts/employee';

@Component({
  selector: 'app-edit-emp-form-builder',
  templateUrl: './edit-emp-form-builder.component.html',
  styleUrls: ['./edit-emp-form-builder.component.css']
})
export class EditEmpFormBuilderComponent implements OnInit {
constructor(private fb: FormBuilder){}
  
regForm = this.fb.group({
  name: ['',Validators.required],
  salary : [''],
  permanent : [''],
  department : ['']
})

get name(){
  return this.regForm.get('name');
}
  
   //for dropdown menu
   departments = [
   
    { id: 1, name: "Payroll" },
    
    { id: 2, name: "Internal" },
    
    { id: 3, name: "HR" }
    
    ];
  
 
  //for greet
  public greet =""
  onClick(){
    this.greet="Details Saved";
  }
  

  //employee detail
  empl : Employee = {
    id: 9,
    fname: "John", 
    dob: new Date('9/20/1998'),
    salary: 3000,
    permanent: true,
    department: {
      id: 6,
      name: "Denting"
    },
    skill: [
      {
        id: 1,
        name: "HTML"
      },
      {
        id: 2,
        name: "CSS"
      },
      {
        id: 3,
        name: "JavaScript"
      }
    ]
  };
    
  
    ngOnInit(): void {
    }

}
